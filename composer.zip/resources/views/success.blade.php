<!-- resources/views/orders/success.blade.php -->
@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Order Success</h1>
        <p>Your order has been placed successfully!</p>
    </div>
@endsection
