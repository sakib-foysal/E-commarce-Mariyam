<?php $__env->startSection('content'); ?>
<div class=""></div>

<main id="main" class="main">

<div class="pagetitle">
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Dashboard</a></li>
      <li class="breadcrumb-item active">Order List</li>
    </ol>
  </nav>
</div>

<section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
              <table class="table datatable table-responsive">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Email</th>
                    <th>Quantity</th>
                    <th>Message</th>
                    <th>Product</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->mobile); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->quantity); ?></td>
                    <td><?php echo e($data->message); ?></td>
                    <td>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#View<?php echo e($data->id); ?>" class="btn btn-primary px-1 py-0 mb-1">View</a>
                    </td>
                    <td><?php echo e($data->status); ?></td>
                    <td>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#Edit<?php echo e($data->id); ?>" class="btn btn-outline-success px-1 py-0 mb-1"><i class="bi bi-pencil-fill"></i></a>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#Delete<?php echo e($data->id); ?>" class="btn btn-outline-danger px-1 py-0 mb-1"><i class="bi bi-trash-fill"></i></a>
                    </td>
                  </tr>

                    <!-- View -->
                    <div class="modal fade" id="View<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            <h3>Product Information</h3>
                            <hr>
                            <div class="row justify-content-center">
                                <div class="col-12">
                                    <span><span class="fw-bold">Name :</span> <?php echo e($data->product->title); ?></span> <br>
                                    <span><span class="fw-bold">Type :</span> <?php echo e($data->product->type); ?></span> <br>
                                    <span><span class="fw-bold">Price :</span> <?php echo e($data->product->sale_price); ?> taka per (<?php echo e($data->product->unit->name); ?>)</span> <br>
                                    <img src="<?php echo e(asset('images/products/'.$data->product->image)); ?>" alt="" class="img-fluid p-5 rounded">
                                </div>
                            </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- Edit -->
                    <div class="modal fade" id="Edit<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Edit User</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="<?php echo e(route('orders.update',$data->id)); ?>" method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
                          <div class="modal-body">
                            <div class="row">

                                <div class="col-12 pb-3">
                                    <label>Status :</label>
                                    <input type="text" name="name" required value="" class="form-control my-2">
                                </div>

                            </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-success">Save Changes</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>

                    <!-- Delete -->
                    <div class="modal fade" id="Delete<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Order</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body text-center fs-3 text-danger">
                            
                            Are you sure ?
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <form action="<?php echo e(route('orders.destroy',$data->id)); ?>" method="post"> <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger">Yes</button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

</main><!-- End #main -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.NiceAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dolphin5/mariyamtraders.com/resources/views/backend/admin/orders/index.blade.php ENDPATH**/ ?>