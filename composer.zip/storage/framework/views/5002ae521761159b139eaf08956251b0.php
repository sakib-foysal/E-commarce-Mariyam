<!-- resources/views/orders/success.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Order Success</h1>
        <p>Your order has been placed successfully!</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\mariyam - Copy - Copy\resources\views/success.blade.php ENDPATH**/ ?>