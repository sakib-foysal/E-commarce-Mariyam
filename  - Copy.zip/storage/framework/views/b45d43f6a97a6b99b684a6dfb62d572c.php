<?php $__env->startSection('content'); ?>

    <main id="main" class="main" style="min-height:70vh;">

      <div class="pagetitle">
        <nav>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>
        </nav>
      </div>



    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.NiceAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\mariyam - Copy - Copy\resources\views/adminHome.blade.php ENDPATH**/ ?>