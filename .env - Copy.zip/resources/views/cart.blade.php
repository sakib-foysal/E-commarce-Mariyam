@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Your Cart</h2>
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif
        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                @foreach($cartItems as $item)
                    <tr>
                        <td>{{ $item->product->title }}</td>
                        <td>{{ $item->quantity }}</td>
                        <td>{{ $item->product->sale_price * $item->quantity }} tk</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <form action="{{ url('/checkout') }}" method="post">
            @csrf
            <button type="submit" class="btn btn-primary">Checkout</button>
        </form>
    </div>
@endsection
