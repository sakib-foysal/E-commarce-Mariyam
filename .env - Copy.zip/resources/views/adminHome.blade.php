@extends('layouts.NiceAdmin')

@section('content')

    <main id="main" class="main" style="min-height:70vh;">

      <div class="pagetitle">
        <nav>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>
        </nav>
      </div>



    </main>

@endsection
