<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;
use App\Models\Product;
use App\Models\Category;
use App\Models\SubCategory;
use App\Models\Order;
use App\Models\OrderVariant;
use App\Models\Setting;
use Auth;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(): View
    {
        $data['setting'] = Setting::first();
        $data['categories'] = Category::latest()->get();
        $data['sub_categories'] = SubCategory::latest()->get();
        if(auth()->check()){

        $data['orders'] = Order::latest()->where('user_id',Auth::user()->id)->where('order_status','complete')->get();

        // cart count er jonno
        $last_incomplete_order_on_user = Order::latest()->where('user_id',Auth::user()->id)->where('order_status','incomplete')->first();
        $data['count_variant'] = OrderVariant::latest()->where('order_id',$last_incomplete_order_on_user->id)->count();
        }
        return view('home',$data);
    }
    public function adminHome(): View
    {
        $data['setting'] = Setting::first();
        $data['t_product'] = Product::count();
        $data['orders'] = Order::latest()->get();
        return view('adminHome',$data);
    }
}
