<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\SubCategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\WelcomeController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\OrderVariantController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\SocialController;
use App\Http\Controllers\EarnNameController;
use App\Http\Controllers\ExpenseNameController;
use App\Http\Controllers\EarnController;
use App\Http\Controllers\ExpenseController;


Route::get('/clear-all', function() { Artisan::call('optimize:clear'); return redirect()->to('/'); });
Route::get('/lanmango', [WelcomeController::class, 'lanmango']);
Route::post('/form-submit', [WelcomeController::class, 'fishinsert'])->name('form.submit');
Route::get('/form-submissions', [WelcomeController::class, 'index2'])->name('form-submissions.index2');

Route::get('/', [WelcomeController::class, 'welcome'])->name('welcome');
Route::get('/shop', [WelcomeController::class, 'shop'])->name('shop');
Route::get('/category_wise_product/{id}', [WelcomeController::class, 'category_wise_product']);
Route::get('/sub_category_wise_product/{id}', [WelcomeController::class, 'sub_category_wise_product']);
Route::get('/product_details/{id}', [WelcomeController::class, 'product_details']);
Route::get('/import_products', [WelcomeController::class, 'import_products']);
Route::get('/export_products', [WelcomeController::class, 'export_products']);
Route::get('/trade_products', [WelcomeController::class, 'trade_products']);
Route::post('/login2/{id}', [WelcomeController::class, 'login2'])->name('login2');

Route::post('/orderNow', [OrderController::class, 'orderNow']);

Auth::routes();



// USER----------------------------------------------------------------------------------------
Route::middleware(['auth', 'user-access:user'])->group(function () {

    Route::get('/home', [HomeController::class, 'index'])->name('home');
    Route::resource('orders', OrderController::class);
    Route::get('/delete_order_variant/{id}', [OrderVariantController::class,'delete_order_variant']);
    Route::put('/update_user_address', [UserController::class,'update_user_address']);
});



// ADMIN---------------------------------------------------------------------------------------
Route::middleware(['auth', 'user-access:admin'])->group(function () {

    Route::get('/admin/home', [HomeController::class, 'adminHome'])->name('admin.home');

    Route::resource('settings', SettingController::class);
    Route::resource('users', UserController::class);
    Route::resource('products', ProductController::class);
    Route::resource('categories', CategoryController::class);
    Route::resource('subcategories', SubCategoryController::class);
    Route::resource('units', UnitController::class);
    Route::resource('orders', OrderController::class);
    Route::resource('socials', SocialController::class);
    Route::resource('earnnames', EarnNameController::class);
    Route::resource('expensenames', ExpenseNameController::class);
    Route::resource('earns', EarnController::class);
    Route::resource('expenses', ExpenseController::class);

    Route::post('/fetch_sub_categories', [ProductController::class, 'fetch_sub_categories']);
    Route::put('/product_variant_quantity_update/{id}', [ProductController::class, 'product_variant_quantity_update']);


});


Route::get('/clear-all', function() { Artisan::call('optimize:clear'); return redirect()->to('/'); });
Route::get('/migrate-fresh', function() { Artisan::call('migrate:fresh'); return redirect()->to('/'); });
Route::get('/migrate-fresh-seed', function() { Artisan::call('migrate:fresh --seed'); return redirect()->to('/'); });
